import { Order } from "../order/order";


export class StudentAddress {
    addressLine1: string;
    state: string;
    city: string;
    postalCode: number;
}

export class Student {
    aadhar: string;
    email: string;
    password: string;
    contact: number;
    gender: string;
    address: StudentAddress;
    orders: string[];
    //orders: Order[];
    //Order
}