import { Order } from "../order/order";


export class Address {
    addressLine1: string;
    state: string;
    city: string;
    postalCode: number;
}
//Customer custObj;
//this.custObj.addr.state.
export class Customer {
    name: string;
    email: string;
    password: string;
    contact: number;
    gender: string;
    address: Address; // customer has Address
    orders: string[];
    //orders: Order[];
    //Order
}