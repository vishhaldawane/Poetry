import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from './customer';
import { Observable } from 'rxjs';
import { Student } from './Student';

@Injectable()
export class CustomerService {

    baseUrl = "http://localhost:8000/";

    constructor(private http: HttpClient) { }

    registerNewCustomer(customer: Customer): Observable<Customer> {
        return this.http.post<Customer>(this.baseUrl + "customers", customer);
    }

    authenticate(customer: Customer): Observable<Customer> {
        return this.http.post<Customer>(this.baseUrl + "customers/login",customer);
    }

    authenticateStudent(student: Student): Observable<Student> {
        return this.http.post<Student>(this.baseUrl + "student/login",student);
    }

    updateCustomerInfo(customer: Customer): Observable<Customer> {
        return this.http.put<Customer>(this.baseUrl + "customers", customer);
    }
}