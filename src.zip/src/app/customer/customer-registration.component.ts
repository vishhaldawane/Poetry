import { Component, OnInit } from '@angular/core';
import { Customer, Address } from './customer';
import { CustomerService } from './customer.service';
import { Router } from '@angular/router';

@Component({
    selector: "customer-signup",
    templateUrl: "./customer-registration.component.html"
})
export class CustomerRegistrationComponent implements OnInit {

    states = ["Maharashtra", "Madhya Pradesh", "Karnataka", "Uttar Pradesh"];
    cities = ["Mumbai", "Bhopal", "Banglore", "Gurgaon"];

    customer: Customer; //filled up by html file

    constructor(private customerService: CustomerService,
                      private router: Router) { }

    ngOnInit() {
        this.customer = new Customer();
        this.customer.address = new Address();
    }
    registerNewCustomer() {
        this.customerService.registerNewCustomer(this.customer).subscribe((data: Customer) => {
            if(data != null) {  // SUBSSCRIBE THE ADD ALSO 
                alert("Registration is successful");
                this.router.navigate(["/customer/login"]); //IGNORE THIS ROUTING
            }
        }, (err) => {
            alert("something went wrong");
            console.log(err);
        })
    }

}