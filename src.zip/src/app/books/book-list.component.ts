/*

    business    scient  programming 
        |
    what list should be provided

        img  title price ratimg
    101 bus
    102 bus
    103 bus

    104 sci
    105 sci
    106 sci
    
    107 pro
    108 pro
    109 pro
*/
import { Component, OnInit } from '@angular/core';
import { BookService } from './book.service';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Book } from './book';
import { Item, Cart } from '../cart/cart';
import { CartService } from '../cart/cart.service';
import { retryWhen } from "rxjs/operators";
import { interval } from 'rxjs/observable/interval';
import { Subscription } from 'rxjs';

@Component({
    templateUrl: "./book-list.component.html",
    selector: "book-list"
})
export class BookListComponent implements OnInit {

    books: Book[];

    constructor(private bookService: BookService,
        private route: ActivatedRoute, // current or actve  route parameter 
        private router: Router,
        private cartService: CartService) { }
        
    private subscription: Subscription;

    cancelOperation() {
        console.log("User canceled the operation...");
        this.subscription.unsubscribe();
    }

    // http://localhost:4200/category
    ngOnInit() {
                        // subscribe will read the latest category vale
        this.route.paramMap.subscribe((map: ParamMap) => {
            let category = map.get("category");//programming or business or scientific
            this.subscription = this.bookService.findBooksByCategory(category)
               
                .subscribe((data: Book[]) => {
                    this.books = data;
                }, (err) => {
                    console.log(err);
                });
        })  // "understand the wiring "
    }

    addToCart(book) { 
        if (sessionStorage.getItem("cart") == null) {
            alert("Please login...");
            this.router.navigate(["/customer/login"]);
        }
        else {
            let cart: Cart = JSON.parse(sessionStorage.getItem("cart"));
            let bookExists = false;
            if (cart.items.length > 0) {
                for (let item of cart.items) {
                    if (item.book.bookId == book.bookId) {
                        item.quantity = item.quantity + 1;
                        bookExists = true;
                        alert("Book already present, new quantity is " + item.quantity);
                        break;
                    }
                }
            }
            if (!bookExists) {
                let item = new Item();
                item.book = book;
                item.quantity++;
                cart.items.push(item);
                alert("Book is added successfully...");
            }
            sessionStorage.setItem("cart", JSON.stringify(cart));
            this.cartService.updateCart(cart).subscribe((data) => {
                //console.log(data);
            })
            this.router.navigate(["/cart"]);
        }
    }
// each group  - Pranav(cust)+3, Harish(ord)+3, Aswitha(cart)+3, Swetha+3(book)
//understanding of wiring of ( html + ts + module + service + routes )
// in a diagramatic manner - 
// thenn all the four leaders would generate a common work flow diagram
// of all the modules - 15 or 50
// pen andpaer diagram - VISUAL DIAGRAM MAKES IT FIXED 
// MENTAL UNDERSTANDING JOTTED DOWN ON THE PAPER
// PICTURES ARE THOUSAND WORDS 
// AS A TEAM LEADER U SHOULD ALLOW THE TEAM MEMBER TO STUDY THE ENTIRE 
//MODULE , EG. ASWHITA REQUESTS THE THEJUS TO STUDY CARD MODULE, AT THE
// SAME TIME THIS MODULE IS STUDIED BY HERSELF, ABINAYA AND NV
// AND THEN JOINTLY DISCUSS THE MODULE - CRYSTAL CLEAR UNDERSTANDING IS REQUIRED
// WHEREVER THERE IS A CHALLANGE - GOOGLE IT<==
// Storage 
    // books = [
    //     {
    //         "bookId": 101,
    //         "imageUrl": "assets/images/her_last_wish.jpeg",
    //         "title": "Her Last Wish",
    //         "price": 250,
    //         "rating": 3.2,
    //         "category": "Biographies"
    //     },
    //     {
    //         "bookId": 102,
    //         "imageUrl": "assets/images/lifes_amazing_secrets.jpeg",
    //         "title": "Lifes Amazing Secrets",
    //         "price": 300,
    //         "rating": 4,
    //         "category": "Biographies"
    //     },
    //     {
    //         "bookId": 103,
    //         "imageUrl": "assets/images/secret_of_nagas.jpeg",
    //         "title": "Secret of Nagas",
    //         "price": 400,
    //         "rating": 4.9,
    //         "category": "Biographies"
    //     }
    // ];
}